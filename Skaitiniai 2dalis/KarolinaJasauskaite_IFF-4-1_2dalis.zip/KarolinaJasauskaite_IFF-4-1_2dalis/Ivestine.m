
syms x xx xxx xxxx
diff(5*x-15*xx+3*xxxx+22, x)
diff(5*x-15*xx+3*xxxx+22, xx)
diff(5*x-15*xx+3*xxxx+22, xxx)
diff(5*x-15*xx+3*xxxx+22, xxxx)

% syms x y
% diff((x^2+y^2)/5-2*cos(x/2)-6*cos(y)-8, x)
% diff((x^2+y^2)/5-2*cos(x/2)-6*cos(y)-8, y)
% 
% diff((x/2)^5+(y/2)^4-4, x)
% diff((x/2)^5+(y/2)^4-4, y)
